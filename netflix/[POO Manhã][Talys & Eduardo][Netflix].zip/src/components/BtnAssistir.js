import './BtnAssistir.css'
import { FaPlay } from "react-icons/fa";

function BtnAssistir(){
    return(
        <div className='btn'>
            <FaPlay />
            <span>Assistir</span>
        </div>
    )
}

export default BtnAssistir  