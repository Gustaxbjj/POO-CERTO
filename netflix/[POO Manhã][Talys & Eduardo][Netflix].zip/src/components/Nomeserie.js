import './Nomeserie.css'

function Nomedaserie(){
    return(
        <div className='Nome'>
            <span>Moon Knight</span>
        </div>
    )
}

export default Nomedaserie